/* ═══════════════════════════════════════════════════
   MELVIN OS — Service Worker v1.0
   Offline cache + background sync
═══════════════════════════════════════════════════ */

const CACHE_NAME = 'melvin-os-v6';
const STATIC_ASSETS = [
  './MELVIN_OS_v7_pwa.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  'https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@300;400;700;900&family=Exo+2:ital,wght@0,200;0,300;0,400;0,600;0,700;1,300&display=swap'
];

/* ── INSTALL: önbelleğe al ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(() => {
        // Font yüklenemezse devam et
        return cache.addAll(['./MELVIN_OS_v7_pwa.html', './manifest.json']);
      });
    })
  );
  self.skipWaiting();
});

/* ── ACTIVATE: eski cache temizle ── */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

/* ── FETCH: önce cache, sonra network ── */
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // API isteklerini (Anthropic, Open-Meteo, Nominatim) direkt geç
  if (
    url.hostname.includes('anthropic.com') ||
    url.hostname.includes('open-meteo.com') ||
    url.hostname.includes('openstreetmap.org') ||
    url.hostname.includes('googleapis.com') ||
    url.hostname.includes('gstatic.com')
  ) {
    e.respondWith(
      fetch(e.request).catch(() => new Response('{}', { headers: { 'Content-Type': 'application/json' } }))
    );
    return;
  }

  // Statik dosyalar: cache-first
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(response => {
        if (response && response.status === 200 && response.type === 'basic') {
          const cloned = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(e.request, cloned));
        }
        return response;
      }).catch(() => {
        // Offline fallback
        if (e.request.destination === 'document') {
          return caches.match('./MELVIN_OS_v7_pwa.html');
        }
      });
    })
  );
});

/* ── PUSH: bildirimler (ileride kullanım için) ── */
self.addEventListener('push', e => {
  const data = e.data?.json() || { title: 'MELVIN', body: 'Bir bildiriminiz var.' };
  e.waitUntil(
    self.registration.showNotification(data.title || 'MELVIN OS', {
      body: data.body,
      icon: './icon-192.png',
      badge: './icon-192.png',
      vibrate: [100, 50, 100],
      data: { url: data.url || './' }
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data.url));
});
