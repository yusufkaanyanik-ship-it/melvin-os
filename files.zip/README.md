# MELVIN OS v6.0 — PWA Kurulum Kılavuzu

## 📁 Dosyalar
Bu klasördeki tüm dosyaları GitHub'a yükle:

| Dosya | Açıklama |
|-------|----------|
| `MELVIN_OS_v7_pwa.html` | Ana uygulama |
| `manifest.json` | PWA profil bilgileri |
| `sw.js` | Service Worker (offline çalışma) |
| `icon-192.png` | Uygulama ikonu (küçük) |
| `icon-512.png` | Uygulama ikonu (büyük) |

---

## 🚀 GitHub Pages'e Yükleme (5 Adım)

### 1. GitHub'da Repo Oluştur
- [github.com](https://github.com) → **New repository**
- İsim: `melvin-os`
- **Public** seç
- **Create repository** tıkla

### 2. Tüm Dosyaları Yükle
- **Add file → Upload files** tıkla
- Bu klasördeki **5 dosyanın hepsini** sürükle bırak
- **Commit changes** tıkla

### 3. GitHub Pages Aç
- **Settings** sekmesine gir
- Sol menüden **Pages** seç
- **Branch: main** → **Save**

### 4. URL'yi Al (1-2 dakika bekle)
```
https://KULLANICI_ADIN.github.io/melvin-os/MELVIN_OS_v7_pwa.html
```

### 5. Telefona Yükle
**iPhone (Safari):**
1. URL'yi Safari'de aç
2. Alt ortadaki **Paylaş** (□↑) butonuna bas
3. **"Ana Ekrana Ekle"** seç
4. **Ekle** bas → Bitti! 🎉

**Android (Chrome):**
1. URL'yi Chrome'da aç
2. Sağ üst **⋮** menüsüne bas
3. **"Ana ekrana ekle"** veya **"Uygulamayı yükle"** seç
4. **Yükle** bas → Bitti! 🎉

---

## ✅ Sonuç
- Ana ekranda **MELVIN ikonu** görünür
- Tam ekran, çerçevesiz açılır
- Mikrofon çalışır (HTTPS sayesinde)
- Offline da açılır (Service Worker)
